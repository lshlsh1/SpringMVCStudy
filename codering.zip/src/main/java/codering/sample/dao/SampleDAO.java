package codering.sample.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import codering.common.dao.AbstractDAO;

@Repository("sampleDAO")
public class SampleDAO extends AbstractDAO	// 상속받음
{
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectBoardList(Map<String, Object> map) throws Exception
	{
		return (List<Map<String, Object>>) selectList("sample.selectBoardList", map);
	}
	// selectList 메소드를 이용한 값을 반환한다.

	public void insertBoard(Map<String, Object> map) throws Exception
	{
		insert("sample.insertBoard", map);
	}

	public void updateHitCnt(Map<String, Object> map) throws Exception
	{
		update("sample.updateHitCnt", map);
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> selectBoardDetail(Map<String, Object> map) throws Exception
	{
		return (Map<String, Object>) selectOne("sample.selectBoardDetail", map);
	}

}