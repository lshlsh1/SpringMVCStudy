package codering.sample.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import codering.common.common.CommandMap;
import codering.sample.service.SampleService;

@Controller
public class SampleController
{
	Logger log = Logger.getLogger(this.getClass());

	// 서비스 DI
	@Resource(name = "sampleService")
	private SampleService sampleService;

	// 게시판 목록
	@RequestMapping(value = "/boardList.action")
	public ModelAndView openSampleBoardList(Map<String, Object> commandMap) throws Exception
	{
		ModelAndView mav = new ModelAndView("boardList");		
		
		List<Map<String, Object>> list = sampleService.selectBoardList(commandMap);

		mav.addObject("list", list);	

		return mav;
	}
	
	
	@RequestMapping(value="/boardWrite.action")
	public ModelAndView openBoardWrite(Map<String, Object> commandMap) throws Exception
	{
		ModelAndView mav = new ModelAndView("boardwrite");		
		
		return mav;
	}
	
	@RequestMapping(value="/boardInsert.action")
	public ModelAndView openBoardInsert(Map<String, Object> commandMap) throws Exception
	{
		ModelAndView mav = new ModelAndView("redirect:/boardList.action");
		
		sampleService.insertBoard(commandMap);
		
		return mav;
	}
	
	
	
	
	
	

	@RequestMapping(value = "/testMapArgumentResolver.action")
	public ModelAndView testMapArgumentResolver(CommandMap commandMap) throws Exception
	{
		ModelAndView mv = new ModelAndView("");
		
		if (commandMap.isEmpty() == false)
		{
			Iterator<Entry<String, Object>> iterator = commandMap.getMap().entrySet().iterator();
			
			Entry<String, Object> entry = null;
			
			while (iterator.hasNext())
			{
				entry = iterator.next();
				
				log.debug("key : " + entry.getKey() + ", value : " + entry.getValue());
			}
		}
		
		return mv;
	}

}