/*
 * 	HelloController.java
 *  - 사용자 정의 컨트롤러 클래스
 */

package com.test.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

// ※ Spring의 『Controller』 인터페이스를 구현하는 방법을 통해
//	  사용자 정의 컨트롤러 클래스를 구성한다
public class HelloController implements Controller
{

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		// 액션 코드
		
		//-- ModelAndView 인스턴스 생성
		//-- ModelAndView는 마트의 쇼핑카트같은 개념 / 틀& 약속
		ModelAndView mav = new ModelAndView();
		
		String message = "Hello, SpringMVC World~!!!";
		
		//-- Object 형식
		//-- setAttribute와 비슷한 개념
		mav.addObject("message", message);
		//-- view가 수신해서 처리하도록 하겠다(객체를 넘겨주는것x/ 경로만 지정)
		mav.setViewName("/WEB-INF/views/Hello.jsp");
		

		return mav;
	}

}
