package com.test.mvc;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

public class PositionDAO implements IPositionDAO
{
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}

	@Override
	public ArrayList<Position> list() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int add(Position position) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int remove(String positionId) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int modify(Position position) throws SQLException
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
