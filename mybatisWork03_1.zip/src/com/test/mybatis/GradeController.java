/*
 *   Sample.java
 *   - 컨트롤러 객체
 */

package com.test.mybatis;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class GradeController
{
	@Autowired
	private SqlSession sqlSession;

	@RequestMapping(value="/gradelist.action", method=RequestMethod.GET)
	public String gradeList(Model model)
	{
		IGradeDAO dao = sqlSession.getMapper(IGradeDAO.class);

		model.addAttribute("list", dao.list());
		
		return "/WEB-INF/views/GradeList.jsp";
	}
	
	@RequestMapping(value="/gradeinsertform.action", method=RequestMethod.GET)
	public String gradeInsertForm()
	{
		return "/WEB-INF/views/GradeInsertForm.jsp";
	}
	
	@RequestMapping(value="/gradeinsert.action", method=RequestMethod.POST)
	public String gradeInsert(GradeDTO g)
	{
		IGradeDAO dao = sqlSession.getMapper(IGradeDAO.class);
		
		dao.add(g);
		
		return "redirect:gradelist.action";
	}
	
}
