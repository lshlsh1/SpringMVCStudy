/*
 *  IStudentDAO.java
 *  - 인터페이스
 */

package com.test.mybatis;

import java.util.ArrayList;

public interface IStudentDAO
{
	public int count();
	
	public int add(StudentDTO m);
	public ArrayList<StudentDTO> list();
	
	public StudentDTO search(String sid);
}
