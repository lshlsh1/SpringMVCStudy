/*
 *   Sample.java
 *   - 컨트롤러 객체
 */

package com.test.mybatis;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class StudentController
{
	@Autowired
	private SqlSession sqlSession;
		
	
	// 매개변수를 정의하는 과정에서 
	// 매개변수 목록에 적혀있는 클래스의 객체 정보는 스프링이 제공한다.
	
	// 사용자의 요청 주소와 메소드를 매핑하는 과정 필요(p37)
	// @RequestMapping(value="요청주소", method=전송방식)
	// 이 때, 전송 방식은 submit 액션인 경우에만 POST
	// 나머지 모든 전송 방식은 GET으로 처리한다.
	@RequestMapping(value="/studentlist.action", method = RequestMethod.GET)
	public String studentList(Model model)
	{
		
		String result = "null";
		
		// 사용자의 요청 주소와 메소드를 매핑하는 과정 필요(p37)
		IStudentDAO dao = sqlSession.getMapper(IStudentDAO.class);
	
		model.addAttribute("count", dao.count());
		model.addAttribute("list", dao.list());
		
		result ="/WEB-INF/views/StudentList.jsp";
		
		return result; 
		
	}
	
	@RequestMapping(value="/studentinsertform.action", method= RequestMethod.GET)
	public String studentInsertform()
	{	
		String result = null;
		
		//IStudentDAO dao = sqlSession.getMapper(IStudentDAO.class);
		//있어도 없어도 됨
		
		result = "/WEB-INF/views/StudentInsertForm.jsp";
		return result;
	}
		
	
	@RequestMapping(value="/studentinsert.action", method = RequestMethod.POST)
	public String studentInsert(StudentDTO s)
	{
		IStudentDAO dao = sqlSession.getMapper(IStudentDAO.class);
		
		dao.add(s);
		
		return "redirect:studentlist.action";
		
	}
	
	@RequestMapping(value="/gradelist.action", method=RequestMethod.GET)
	public String gradeList(Model model)
	{
		IGradeDAO dao = sqlSession.getMapper(IGradeDAO.class);

		model.addAttribute("list", dao.list());
		
		return "/WEB-INF/views/GradeList.jsp";
	}
	
	@RequestMapping(value="/gradeinsertform.action", method=RequestMethod.GET)
	public String gradeInsertForm()
	{
		return "/WEB-INF/views/GradeInsertForm.jsp";
	}
	
	@RequestMapping(value="/gradeinsert.action", method=RequestMethod.POST)
	public String gradeInsert(GradeDTO g)
	{
		IGradeDAO dao = sqlSession.getMapper(IGradeDAO.class);
		
		dao.add(g);
		
		return "redirect:gradelist.action";
	
	}
	
}
