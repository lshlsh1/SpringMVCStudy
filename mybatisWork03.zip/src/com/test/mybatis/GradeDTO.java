package com.test.mybatis;

public class GradeDTO
{
	//주요 속성 구성
	private int sid, name, sub1, sub2, sub3, tot, avg, ch;

	// ※ 참고사항
	//    원칙적으로는 각 데이터 타입이 있고
	//    여기에 맞춰 속성 타입을 지정하는 것이 맞다.
	//    (String, int, double등)
	//    하지만, 오라클에서 NUMBER로 구성되어 있는 정수 및 실수를 숫자로 구성할 떄 
	//    null에 대한 컨트롤이 까다로워질 수 있다.
	//    이와 같은 이유로 실무에서는 편의상 String으로 구성하는 경우가 많다.
	//    날짜(Date) 타입도 적용된다.
	
	//    즉, sub1, sub2, sub3, tot, avg 와 같이 상황에 따라 null이 적용될 가능성이 농후한 컬럼의 경우
	//    String 자료형을 사용하는 것이 편할 수 있다는 것이다.
	
	// getter / setter 	
	public int getSid()
	{
		return sid;
	}

	public void setSid(int sid)
	{
		this.sid = sid;
	}

	public int getName()
	{
		return name;
	}

	public void setName(int name)
	{
		this.name = name;
	}

	public int getSub1()
	{
		return sub1;
	}

	public void setSub1(int sub1)
	{
		this.sub1 = sub1;
	}

	public int getSub2()
	{
		return sub2;
	}

	public void setSub2(int sub2)
	{
		this.sub2 = sub2;
	}

	public int getSub3()
	{
		return sub3;
	}

	public void setSub3(int sub3)
	{
		this.sub3 = sub3;
	}

	public int getTot()
	{
		return tot;
	}

	public void setTot(int tot)
	{
		this.tot = tot;
	}

	public int getAvg()
	{
		return avg;
	}

	public void setAvg(int avg)
	{
		this.avg = avg;
	}

	public int getCh()
	{
		return ch;
	}

	public void setCh(int ch)
	{
		this.ch = ch;
	}

	

}
